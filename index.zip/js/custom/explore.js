$(function(){
	$(window).load(function(){
		$('.rounded-rating').tooltip({
			placement : 'right'
		});
		
	});
});