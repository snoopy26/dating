<div class="header-title">
	<h1>Welcome, <?php echo $member->member_name; ?>.</h1>
	<h6>Alamat email anda berhasil kami verifikasi. Sebentar lagi, anda akan masuk dalam dunia cinta kamu. Silahkan melengkapi informasi anda.</h6>
</div>