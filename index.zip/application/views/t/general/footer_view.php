		
		<!-- js tags default -->
		<script type="text/javascript" src="<?php echo $js_tags; ?>"></script>
		
		<!-- js tags custom -->
		
		<!-- google analytics -->
		
	</body>
</htmL>