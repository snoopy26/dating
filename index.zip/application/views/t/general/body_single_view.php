<body class="single-page-theme">
		
	<div class="single-page">