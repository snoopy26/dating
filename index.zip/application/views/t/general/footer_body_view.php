		<div class="container product-feature">
			<!-- footer -->
			<div class="footer">
				<p>&copy. 2012. Twobecome.us. All Rights Reserved.</p>
			</div>
		</div>	