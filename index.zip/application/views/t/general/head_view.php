<!DOCTYPE HTML>
<html lang="en">
	<head>
		<meta charset="UTF-8" />
		<title><?php echo (!empty($info_name) ? $info_name ." - ": ""); ?>Twobecome.us | Premium Dating Online</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		
		<!-- css tags default -->
		<link rel="stylesheet" type="text/css" href="<?php echo $css_tags; ?>" />

		<!-- css tags custom -->
	
	</head>